<?php
foreach($segment as $s){
    echo $s.'<br>';
}

echo '<h1>Email Send Successfully!!</h1>';
?>