<!DOCTYPE html>
<head>
    <title>Log In</title>
</head>
<body>
    <table cellspacing="20">
        <tr>
            <th> Username </th>
            <td><input type="username" name="stuname"></td>
        </tr>
        <tr>
            <th> Password </th>
            <td><input type="password" name="stpwd"></td>
        </tr>
        <tr>
            <td>  </td>
            <td><input type="submit" name="submit" value="Log In"></td>
        </tr>
    </table>
</body>
</html>
    